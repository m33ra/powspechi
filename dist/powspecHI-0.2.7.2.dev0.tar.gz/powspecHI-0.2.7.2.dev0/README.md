# powspecHI
Simple python library for angular power spectral analysis of heavy-ion data - coupled to HEALPix

Requirements: healpy 1.12.10
It should be remarked that numpy, scipy and matplotlib are installed together with healpy.
